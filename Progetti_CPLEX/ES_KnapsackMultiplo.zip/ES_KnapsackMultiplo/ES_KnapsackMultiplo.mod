/*********************************************
 * OPL 22.1.0.0 Model
 * Author: studente
 * Creation Date: 24 nov 2025 at 10:08:51
 *********************************************/
 
//La banda bassotto rapina la gioielleria di ivan grande, quanti e quali oggetti prendono?

 int numeroOggetti = ...;
 int numeroBisacce = ...;
 
 range oggetti = 1..numeroOggetti;
 range bisacce = 1..numeroBisacce;
 
 //Dati
 int valore[oggetti] = ...; //Valore degli oggetti di ivan grattata
 int capacita[bisacce] = ...; //Capacit� delle borse per rubare ad ivan grandissimo
 int ingombro [oggetti] = ...; //ingombo di ogni ogetto rubato a ivan grandangolo
 
 dvar int x[bisacce][oggetti] in 0..1; //Coppia oggetto-bisacce rubate ad ivan gradiente, assumono valore 0 oppure 1
 
 //modello in cui vogliono massimizzare i danni ad ivan graduatoria
 maximize sum( i in bisacce, j in oggetti ) valore[j]*x[i][j];
 
 //Vincoli
 subject to {
   
   		forall ( j in oggetti )
   		  sum ( i in bisacce ) x[i][j] <= 1; //In pratica ogni oggetto pu� essere messo nella bisaccia oppure no
   		forall ( i in bisacce )
   		  sum ( j in oggetti ) ingombro[j]*x[i][j] <= capacita[i]; //quanto ingombra l'oggetto in bisaccia se preso'
   }