/*********************************************
 * OPL 22.1.0.0 Model
 * Author: studente
 * Creation Date: 1 dic 2025 at 09:31:32
 *********************************************/

 //Numero di impianti
 int n = ...;
 
 //Nuemro clienti
 int m = ...;
 
 int p = ...; //numero impianiti da costruire
 
 //Range per i cicli e array
 range impianti = 1..n;
 range clienti = 1..m;
 
 //Costi di afferenza
 int c[clienti][impianti] = ...;

 //Variabili decisionali
 dvar int x[clienti][impianti] in 0..1;
 
 dvar int y[impianti] in 0..1; //Dichiarazione variabile di tipo boolean
 
 dvar float+ C_max; //Costo massimo
 
 //funzione obiettivo
 minimize C_max;
 
 //vincoli
 subject to {
   
   		forall(i in clienti )
   		  sum (j in impianti ) x[i][j] == 1; //Vincoli di scelta multipla
   		forall( i in clienti, j in impianti )
   		  x[i][j] <= y[j];
   		sum (j in impianti ) y[j] == p;
   		forall( i in clienti, j in impianti )
   		  C_max >= c[i][j]*x[i][j]; //Cosi prendo il costo massimo dei clienti
   }