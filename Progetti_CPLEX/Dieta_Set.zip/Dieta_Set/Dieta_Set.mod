/*********************************************
 * OPL 22.1.0.0 Model
 * Author: studente
 * Creation Date: 3 nov 2025 at 09:51:26
 *********************************************/

//Dati
{string} alimenti =...;  
{string} nutrienti =...;  

float C[alimenti] = ...;
int U[nutrienti] = ...;
int L[nutrienti] = ...;
float A[nutrienti][alimenti] = ...;

dvar float+ X[alimenti];

minimize sum ( j in alimenti ) C[j]*X[j];

subject to {
  
  		forall ( i in nutrienti )
  		  vincoliUpperBound: sum ( j in alimenti ) A[i][j]*X[j]<=U[i];
  		 forall ( i in nutrienti )
  		   vincoliLowerBound: sum (j in alimenti ) A[i][j]*X[j]>=L[i];
  
  }