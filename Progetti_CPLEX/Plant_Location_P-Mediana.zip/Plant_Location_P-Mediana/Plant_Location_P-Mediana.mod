/*********************************************
 * OPL 22.1.1.0 Model
 * Author: proprietario
 * Creation Date: 4 dic 2025 at 15:26:56
 *********************************************/

 //Comincio con il prendere il numero di impianti dal file dat
 int nImpianti = ...;
 
 //Prendo anche il numero di utenti da servire
 int nUtenti = ...;
 
 //Prendo il numero di impianti da abilitare
 int p = ...;
 
 //Creo dei range da usare come indici per le variabili
 range impianti = 1..nImpianti;
 range utenti = 1..nUtenti;
 
 //Ora con i range do dimensione alla matrice e prendo i dati dal dat
 int cAff[utenti][impianti] = ...; //Quanto costa all'utente m andare nell'impianto n
 
 //Definisco le variabili decisionali del problema
 dvar int x[utenti][impianti] in 0..1; //L'utente m è servito nell'impianto n
 dvar int y[impianti] in 0..1; //Se l'impianto n è attivo o no
 
 //Scrittura funzione obiettivo
 minimize sum ( i in utenti, j in impianti ) cAff[i][j]*x[i][j];
 //Minimizzare i costi scegliendo i migliori impianti da attivare
 
 //Aggiunta vincoli
 subject to {
   
   forall ( i in utenti ) //Questo vincolo dice che ogni utente deve essere servito
     sum ( j in impianti ) x[i][j] == 1; 
   
   forall ( i in utenti, j in impianti)
     x[i][j]<=y[j]; //Questo vincolo mi dice che un utente m non può essere servito da un centro n non attivo
     
   sum ( i in impianti )  y[i] == p; //Questo vincolo dice che il numero n di impianti deve essere uguale a p cioè quanti impianti attivare
     
   }