/*********************************************
 * OPL 22.1.0.0 Model
 * Author: studente
 * Creation Date: 5 dic 2025 at 11:55:38
 *********************************************/

 int nNodi = ...;
 range Nodi = 1..nNodi;
 
 int c[Nodi][Nodi] = ...;
 dvar int+ x[Nodi][Nodi] in 0..1; //Variabili decisionali
 dvar float+ u[Nodi];
 
 //ATSP Formulazione MZT
 minimize sum ( i in Nodi ) sum ( j in Nodi: j != i ) c[i][j]*x[i][j];
 
 subject to {
   		forall ( i in Nodi )
   		  sum ( j in Nodi: j != i ) x[i][j] == 1;
   		forall ( i in Nodi )
   		  sum ( j in Nodi: j != i ) x[j][i] == 1;
   		//Vincoli di eliminazione dei sottocicli MZT
   		forall ( i, j in Nodi: i!= 1 && j!=1 && i!=j )
   		  u[i]-u[j]+nNodi*x[i][j]<=nNodi-1;
   }