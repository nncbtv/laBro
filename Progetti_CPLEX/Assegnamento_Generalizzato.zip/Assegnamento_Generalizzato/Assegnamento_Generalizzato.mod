/*********************************************
 * OPL 22.1.0.0 Model
 * Author: studente
 * Creation Date: 1 dic 2025 at 08:48:26
 *********************************************/

//Lezione 5

//Numero Contenitori
int m = ...;

//Numero di Oggetti
int n = ...;

//Range per il ciclo
range contenitori = 1..m;
range oggetti = 1..n;

//Valore oggetti
int v[contenitori][oggetti] = ...;

//Ingombro
int w[contenitori][oggetti] = ...;

//Capacit� contenitori
int b[contenitori] = ...;

//Variabili decisionali
dvar int x[contenitori][oggetti] in 0..1;

//Funzione obiettivo
maximize sum (i in contenitori, j in oggetti) v[i][j]*x[i][j];

//Vincoli
subject to {
  
  		forall ( j in oggetti )
  		  sum ( i in contenitori) x[i][j] == 1;
  		forall ( i in contenitori )
  		  sum ( j in oggetti ) w[i][j]*x[i][j] <= b[i]; 
  }