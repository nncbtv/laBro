/*********************************************
 * OPL 22.1.0.0 Model
 * Author: studente
 * Creation Date: 24 nov 2025 at 08:52:10
 *********************************************/

 int numeroOrigini = ...; //Numero Sorgenti
 int numeroDestinazioni = ...; //Numero pozzi
 
 range origini = 1..numeroOrigini; //Insieme sorgenti
 range destinazioni = 1..numeroDestinazioni; //Insieme pozzi
 
 //Disponibilit� delle origini vista come array
 int Disponibilita[origini] = ...;
 
 //Richiesta dei pozzi 
 int Richiesta[destinazioni] = ...;
 
 //Costi archi
 int Costo[origini][destinazioni] = ...;
 
 //Variabili decisionali
 dvar float+ F[origini][destinazioni];
 
 //Funzione obiettivo
 minimize sum( i in origini, j in destinazioni ) Costo[i][j]*F[i][j];
 
 //Vincoli
 subject to {
   
   		forall ( i in origini )
   		  sum ( j in destinazioni ) F[i][j] <= Disponibilita[i];
   		forall ( j in destinazioni )
   		  sum ( i in origini ) F[i][j] >= Richiesta[j];
   }
//Prendere la soluzione ottima di questo e disegnare il grafo con tutti gli arichi di flusso non nullo