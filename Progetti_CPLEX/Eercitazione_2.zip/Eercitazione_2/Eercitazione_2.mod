/*********************************************
 * OPL 22.1.0.0 Model
 * Author: studente
 * Creation Date: 3 nov 2025 at 08:35:19
 *********************************************/
/*Produzione ordinaria 18�/kg straordinario 22�/kg, capacit� produttiva 100kg/mese con straordinari 125kg/mese
 Dicembre 120kg 
 Gennaio 110kg
 Febbraio 90kg
 Marzo 40kg
 Aprile 130kg
 L'inveduto resta in una cella per il prossimo mese che costa 0.3�/kg con capacit� di 20kg
 Assumiamo che a dicembre le scorte sono di 10kg e ad Aprile deve rimanere vuota
 Sviluppare il piano di produzione mensile che minimizzi i costi di produzione.
 */

//Richiamo i mesi di produzione dal file dat
int Nmesi = ...;

//Creo gli indici per gli array
int QN = ...;  //Quantità prod normale
int QE = ...; //Quantità prod extra
int QC = ...; //Quantità cella
int CN = ...; //Costo normale
int CE= ...;  //Costo extra
float CS = ...; //Costo cella
range mesi = 1..Nmesi;
int D[mesi] = ...; //Array domanda
float SO = ...; //Stato odierno/invenduto

//Incognite decisionali
dvar float+ X[mesi];
dvar float+ Y[mesi];
dvar float+ Z[mesi];

//Modello matematico
minimize sum( i in mesi ) (CN*X[i]+CE*Y[i]+CS*Z[i]);

subject to {
  
  		vinCapProdN: forall( i in mesi ) X[i]<=QN;
  		vinCapPordE: forall ( i in mesi ) Y[i]<=QE;
  		vinCapCella: forall ( i in mesi ) Z[i]<=QC;
  		statoFinaleC: Z[5]==0;
  		soddDom0: X[1]+Y[1]+SO == D[1]+Z[1];
  		forall ( i in mesi: i>= 2 ) X[i]+Y[i]+Z[i] == D[i] + Z[i];
  }
