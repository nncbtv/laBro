/*********************************************
 * OPL 22.1.1.0 Model
 * Author: USER
 * Creation Date: 8 nov 2025 at 11:41:45
 *********************************************/

 {string} mesi = ...; //Set preso dal file dat
 
 tuple quantitaCosti { //Record delle quantità, costi e domanda
   			int normale; //Quantità produzione normale
   			int extra; //Quantità produzione extra
   			int cn; //Costo produzione normale
   			int ce; //Costo produzione extra
   			float cc; //Costo cella
   			int domanda; //Domanda mensile
   		};

quantitaCosti q[mesi] = ...; //Richiamo i dati del record, tanti quanto i mesi

int capCella = ...; //Prendo la capacità della cella dal file dat

int invendutoPartenza = ...; //Prendo l'invenduto del primo mese dal file dat
string mesePartenza = ...;

//Variabili decisionali
dvar float+ X[mesi]; //Produzione normale
dvar float+ Y[mesi]; //Produzione extra
dvar float+ Z[mesi]; //Stock della cella

//Funzione obiettivo, minimizzare i costi di produzione
minimize sum ( i in mesi )(q[i].cn*X[i]+q[i].ce*Y[i]+q[i].cc*Z[i]);

//Vincoli del problema
subject to{
  
  //Vincolo sulla produzione normale
  forall ( i in mesi )
    X[i]<=q[i].normale; //La produzione normale deve soddisfare la quantità normale
  
  //Vincolo sulla produzione extra
  forall ( i in mesi )
    Y[i]<=q[i].extra; //La produzione extra deve soddisfare la quantità extra
  
  //Vincoli stoccaggio
  forall ( i in mesi )
    Z[i] <= capCella; //La capacità stoccata non deve superare quella della cella
  Z["Aprile"] == 0; //La cella a fine produzione deve essere vuota
  
  //Partenza primo mese
  X["Dicembre"]+Y["Dicembre"]+invendutoPartenza == q["Dicembre"].domanda+Z["Dicembre"];
  
  
  forall ( i in mesi : i>="Gennaio")
    X[i]+Y[i]+Z[mesePartenza] == q[i].domanda+Z[i];
    mesePartenza = i;
    
  }