/*********************************************
 * OPL 22.1.0.0 Model
 * Author: studente
 * Creation Date: 1 dic 2025 at 09:31:32
 *********************************************/

 //Numero di impianti
 int n = ...;
 
 //Nuemro clienti
 int m = ...;
 
 //Range per i cicli e array
 range impianti = 1..n;
 range clienti = 1..m;
 
 //Costi di attivazione
 int f[impianti] = ...;
 
 //Costi di afferenza
 int c[clienti][impianti] = ...;
 
 //capacit� impianti
 int K[impianti]= ...;
 
 //domande clienti
 int D[clienti] = ...;
 
 //Variabili decisionali
 dvar int x[clienti][impianti] in 0..1;
 
 dvar int y[impianti] in 0..1; //Dichiarazione variabile di tipo boolean
 
 //funzione obiettivo
 minimize sum(i in clienti, j in impianti ) c[i][j]*x[i][j]+sum (j in impianti) y[j];
 
 //vincoli
 subject to {
   
   		forall(i in clienti )
   		  sum (j in impianti ) x[i][j] == 1; //Vincoli di scelta multipla
   		forall( j in impianti )
   		  sum ( i in clienti) D[i]*x[i][j] <= K[j]*y[j]; 
   
   }